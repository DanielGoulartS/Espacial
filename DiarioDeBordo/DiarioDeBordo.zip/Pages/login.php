<link rel="stylesheet" href="../../Style/Login.css"/>
<form id="loginForm" method="post">
    <div>
    <label>Email:
        <input type="email" name="usuario"></input>
    </label>
    <br>
    <label>Senha:
        <input type="password" name="senha"></input>
    </label>
    <br>
    <input id="submit" type="submit" value="LOGIN"/>
    </div>
</form>