<?php

interface Objeto{
    
    function exibir();
    
}